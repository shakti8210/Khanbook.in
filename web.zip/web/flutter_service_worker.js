'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"ads.txt": "08eb9a258207c910acb51362487a2029",
"assets/AssetManifest.bin": "fc338620fbbc608807098bfad13fecf9",
"assets/AssetManifest.bin.json": "5d0219efa3572fc0a6201da51ecc2c2c",
"assets/AssetManifest.json": "e4ae7bffa2a4bdd0b24ddbfee0169d9b",
"assets/assets/audio/card_audio.mp3": "07bf19f7dea5ef091b7b018d654e8ca6",
"assets/assets/audio/tring_sound.mp3": "665a94888075fb04e741bb08d72124fb",
"assets/assets/fonts/ProximaNova-Regular.otf": "410504d49238e955ba7dc23a7f963021",
"assets/assets/fonts/ProximaNovaBold.otf": "62d4d7d369292a9bf23762465ec6d704",
"assets/assets/fonts/ProximaNovaThin.otf": "8f0bc01ce5e5becef482d277cb72b728",
"assets/assets/icons/about_thriive.svg": "747c807d81ea77377ddfc94b22501087",
"assets/assets/icons/activeAppointmentIcon.svg": "29f31a8c643c1141cf65b663956b24bc",
"assets/assets/icons/activeHelpCircleIcon.svg": "078a087dad30b82ef818fcd83bb4156c",
"assets/assets/icons/activeHomeIcon.svg": "49f136556a818d043e67cacb05d2b189",
"assets/assets/icons/activeInstantIcon.svg": "ce5a7e3c6642c40140657f8365b45a5c",
"assets/assets/icons/angry.png": "9740b16734bf2f9d88de233bef8e29eb",
"assets/assets/icons/angryActive.png": "725c5fe01de6e39bb5c98a91a7249ee5",
"assets/assets/icons/appointment.svg": "c5c5cf3d455f03db76498b88f4df2d01",
"assets/assets/icons/arrowSymbol.svg": "0adcbc913a07daf528a2a3194d9deb14",
"assets/assets/icons/arrow_up_down.svg": "4570c598f24056eb4ea5cfea1fa0103e",
"assets/assets/icons/attachMent.svg": "066bfd087eb214b42cf938068fe58b64",
"assets/assets/icons/audiochat.png": "11c49b381104b3c50be70f122bf4d1c8",
"assets/assets/icons/Banking.png": "03f89782ade27b1248bc88d98011b23e",
"assets/assets/icons/bell.svg": "b18cb570d5ec7a6d3c34f0047d7502d4",
"assets/assets/icons/bellIcon.svg": "e16f1cbe6432ce198eb7ec2cb57fbf0c",
"assets/assets/icons/Bihar_tet.png": "7d177470830bd47a47a9565f5246a105",
"assets/assets/icons/BPSC.png": "132173f6bb642634617950b049ab98d8",
"assets/assets/icons/calender.svg": "a9a1c2447f558a436b0f452684fe714f",
"assets/assets/icons/calenderSymbol.svg": "338ac73490f9f091048d93d6a78635b0",
"assets/assets/icons/call.svg": "40897510ded719d4331782b4b8b76b36",
"assets/assets/icons/cancel.svg": "6ce2b33d12a649fe44551aa4366e5f27",
"assets/assets/icons/chat.svg": "2f5fb7a50214ea2dbaca91a760fd2fa4",
"assets/assets/icons/choice.png": "308bf8064c5c030a004ac988b97d2827",
"assets/assets/icons/clock.svg": "0f32fae6a275adfb06dab681be8e7204",
"assets/assets/icons/clockColor.svg": "608c92f8d887c605f15faee0f0ac81d1",
"assets/assets/icons/contactUs.svg": "36cef09f9f5ae7a714d170156aa4d766",
"assets/assets/icons/CTET.png": "b17203afefac21ad1437fefd3ab6d37b",
"assets/assets/icons/danger.png": "4b6eeb9efa358db3ca4b8b2a40f36e13",
"assets/assets/icons/DebitCard.png": "d2fde2be24a1f5ed4d293b18e8ae9ddc",
"assets/assets/icons/document.png": "f7c444487cbf5aa73aa96e18e72017e3",
"assets/assets/icons/doubleInvertedCommas.svg": "aa931f898588c6c3c8485117b96f804e",
"assets/assets/icons/editicon.svg": "172cfcd443053c55272c40b654dfed9b",
"assets/assets/icons/english.svg": "94a7efecf493f996c2faf4596614a1a0",
"assets/assets/icons/exp.svg": "98ef12429d3b4e857eba13c66af05e49",
"assets/assets/icons/faq.png": "3c5cce25044bba698ded3f0c167c5548",
"assets/assets/icons/faq.svg": "a774eb23182a29a4ec51ca7efcef7371",
"assets/assets/icons/faqnew.svg": "ebc60fed6532224a3ea00e90337b8ebf",
"assets/assets/icons/feel1.png": "509de11fb70cca119cf69fc2e34d5963",
"assets/assets/icons/feel2.png": "8e9d1062b970409f310a380f9eba5ee5",
"assets/assets/icons/feel3.png": "cc507f9d80c32cad3d3beddbb035b6da",
"assets/assets/icons/feel4.png": "85fe8360bbe3806851cffedabf10084f",
"assets/assets/icons/feel5.png": "284c6645e2796693d743c608af639d57",
"assets/assets/icons/female.svg": "fede20fd092b9fb4a18919329a5cac7f",
"assets/assets/icons/filterIcon.png": "0087b5da58b1c8bd19c958ed0bd1d7e5",
"assets/assets/icons/fi_bell.svg": "e16f1cbe6432ce198eb7ec2cb57fbf0c",
"assets/assets/icons/GooglePay.png": "a1ef89a76caa793866b76a64803aa13f",
"assets/assets/icons/happy.png": "fde1f735c0204daaeab304ea6c7649d4",
"assets/assets/icons/happyActive.png": "270e97e18b95f76dae51e77cefdbdb1e",
"assets/assets/icons/heartQuote.svg": "9fbd3fd1349e85570f368d87207af290",
"assets/assets/icons/help.svg": "da9ec7fd6f6c22b34f9dc0edf290dc3b",
"assets/assets/icons/helpCenter.svg": "c438d3d4aac10efaa8c58651adf3ef0d",
"assets/assets/icons/help_circle.svg": "8739c695c6f2218b608c154b3a83af79",
"assets/assets/icons/help_support.svg": "0e8634c6d2170117e9cb60c4abc76921",
"assets/assets/icons/highStress.svg": "a72322ba0716dd4b6660ed927352904b",
"assets/assets/icons/highStressActive.svg": "6d658a5c1db6aa617682870fbe180b26",
"assets/assets/icons/homeIcon.svg": "14fd2e0b81013b7592083f203f8a57c1",
"assets/assets/icons/ic_search.svg": "ff77cce3834b410ec10b7927e2760055",
"assets/assets/icons/image.png": "d590fd9ed7392fcb0aa12ae10fa2ca0b",
"assets/assets/icons/infoIcon.svg": "4910b9c0508589654ea12dfb6dd8221f",
"assets/assets/icons/instant.svg": "c879b1f97f6bc6e337879071211ff79f",
"assets/assets/icons/jobTypeIcon.svg": "c013c9b0d0e3d69e626339c9225b2ac5",
"assets/assets/icons/languageIcon.svg": "8f40c4986c46cbc15d15604ff97a938c",
"assets/assets/icons/lifeCoachIcon.svg": "a13a80b3e51db546ba3d9fe84499dfde",
"assets/assets/icons/location.svg": "76a74e6cf46dee8c8bc9dc28c8cbcbee",
"assets/assets/icons/logout.svg": "347e20179fbcd00f3d4a910f09f0f9b8",
"assets/assets/icons/lowStress.svg": "83fc18c89cd4eedcec62ddc729ee7fa4",
"assets/assets/icons/mail.svg": "e483bb76a227c781937a0e69fb8e294e",
"assets/assets/icons/male.svg": "7db94d700a0c22550b610438c8a9481d",
"assets/assets/icons/mediumStress.svg": "27d0adf18df403303de7622278c30979",
"assets/assets/icons/mediumStressActive.svg": "b0c37788ccfa052e23c5eb77e0a29332",
"assets/assets/icons/moreVertical.svg": "919d44ca19f2c492dd9e8000b2a2a5ca",
"assets/assets/icons/NDA.png": "17b2f2b795be34f05eaa1bf0033b5931",
"assets/assets/icons/nda.svg": "1a756d5c26ffe180f4e13bde177328e5",
"assets/assets/icons/NetBanking.png": "be39c60663d8c825473c868c36cd5dd3",
"assets/assets/icons/noun-muscle-pain.svg": "b65104b1e88bbfdcab8f5a899be28577",
"assets/assets/icons/offlineCall.svg": "a3aeaf42ea42df555694099e1ec7e81e",
"assets/assets/icons/offlineChat.svg": "186f2c9ad3cc69c3d40cb1b0a5d10dbb",
"assets/assets/icons/onlineCall.svg": "4b307a91749d7624fb94f8dae22fbfa9",
"assets/assets/icons/onlineChat.svg": "4a7b2aa8eae2c6396499c484f8bcd257",
"assets/assets/icons/Paytm.png": "5a6aa5d2549764531c09f30986a2b480",
"assets/assets/icons/phone.svg": "8ae3585043e09042a09d6458c2c3b484",
"assets/assets/icons/PhonePay.png": "091fd02021a4db0687139f10324c335f",
"assets/assets/icons/profileCall.svg": "04c4d3fd47e32099c0e95436945b592c",
"assets/assets/icons/profileChat.svg": "a9b377588f1b8d0bac140e14c717e59b",
"assets/assets/icons/qCall.svg": "b5ed478d92d1a09b6c40be0ec3c7af5f",
"assets/assets/icons/qChat.svg": "62cd42e4cfb5bdf9de04c2dc62bb4156",
"assets/assets/icons/Railway.png": "297679b8968eb27723713574ebcf758c",
"assets/assets/icons/railway.svg": "30af023a850258fe28fcbdff75b601d4",
"assets/assets/icons/rsSumbol.svg": "66f7575eb8c8a92a9a0ae163fdbaa1b7",
"assets/assets/icons/sadly.png": "b3c792f2c200d75a75bb86fb5a119d5b",
"assets/assets/icons/searchIcon.svg": "14cac84b269002767e14be2432a056cb",
"assets/assets/icons/sed.png": "be4adc4aa68138caf7fe79dd17f3739d",
"assets/assets/icons/sedActive.png": "8fca00db9dffb9be680e27bfd5e47f6b",
"assets/assets/icons/seenIcon.svg": "16518e90330f1733d1e534c0367a050e",
"assets/assets/icons/send.svg": "918489d0cd4b48699bf01e86f7d35032",
"assets/assets/icons/sessionHistoryCallIcon.svg": "b26841974e63a4d96b984790694ec6ae",
"assets/assets/icons/sessionHistoryChatIcon.svg": "d7bb825b2606699dd966e0ce2da9ac0d",
"assets/assets/icons/session_history.svg": "a3940276e9d8f8113d837d3697207a2d",
"assets/assets/icons/setting.svg": "e73f6f36251411706f594f0927eab9b4",
"assets/assets/icons/share.svg": "706defcef3371df099d67b156ee5f90b",
"assets/assets/icons/shareThisApp.png": "298f8e55134f1def8077f2589f27bd44",
"assets/assets/icons/smile.png": "72ae14ad81de93d352fe2b733aa656b0",
"assets/assets/icons/smileActive.png": "d89be782e38326b10099d02f6b2332bb",
"assets/assets/icons/special.png": "d907af44c6ed3411513f21e90c679477",
"assets/assets/icons/SSC.png": "14c3f8e2ba19dc568a91647b78c9fc79",
"assets/assets/icons/ssc.svg": "ace64aca5871b964d85e04bfc1251dc9",
"assets/assets/icons/star.svg": "8bc3b2228d8caf66d581c3eaeb7bfeba",
"assets/assets/icons/stopwatch.svg": "641049f9c2ba6fad5bc32b283fe2b959",
"assets/assets/icons/sucessfully.svg": "2222801b015dfc0f36c9ef80a437f3c1",
"assets/assets/icons/tarotSymbol.svg": "45d0540c7d92af3bd6db032731d7cafd",
"assets/assets/icons/term.png": "0a249c854a33afe97295d8d9b79fa6d7",
"assets/assets/icons/term.svg": "ff3ed71172a8acbbb2f0236a324d46e3",
"assets/assets/icons/timerSymbol.svg": "72a1225e5c0fa9fed6f0b4b8ef5af051",
"assets/assets/icons/transaction_history.svg": "66663fa36d6146009ec7028863ae1a06",
"assets/assets/icons/unsucessfully.svg": "30d2e768388f936990d863fb22449f29",
"assets/assets/icons/upsc.png": "5b5a307e4b464a45ebcf2b279128d26e",
"assets/assets/icons/u_crockery.svg": "a4b4a94de66bbaf3d28ad1172f55a9bd",
"assets/assets/icons/u_dumbbell.svg": "f4883e850ae7fe288fee5bd970ebf502",
"assets/assets/icons/u_weight.svg": "4d3d5ceb4119e60af5fd37f479271d33",
"assets/assets/icons/u_wheelchair.svg": "1e8ae39f263f7ecaebbe627f8a2708ba",
"assets/assets/icons/veryHappy.png": "2dc650b6298642b853eb30f17c5af895",
"assets/assets/icons/veryHappyActive.png": "5af9bfd416e3534bc73c6859c49848b5",
"assets/assets/icons/videocall.png": "d34af5aca4f599431a2d87befaad4f43",
"assets/assets/icons/videoChat.png": "4efc6e91353d184ff9dd5f02b645c402",
"assets/assets/icons/vidoDuration.svg": "476ee9b5ed58c719121f5ada09d66858",
"assets/assets/icons/wallet.svg": "e9fbc3066d44daa62d34c18918bd8925",
"assets/assets/icons/watchIcon.svg": "0b514397b6e021f1a3edd044d384f7f8",
"assets/assets/icons/watsapp.png": "c42be38acb034485bae4385ff3af36ca",
"assets/assets/icons/whatsapp.png": "798614954f313faee40cd9660bf8db40",
"assets/assets/icons/yearOfExp.svg": "72726d8b2ca135ba1ba569ec9e8ebbb3",
"assets/assets/images/app_icon.png": "ac897c5142e5962214787ccd81e0d82c",
"assets/assets/images/app_icon_old.png": "e2aa89770b3314e75c28b034fa5b3d03",
"assets/assets/images/button_loader.json": "fc29687205a6472efb2d8466c3968e01",
"assets/assets/images/chatBg.png": "04c67ffb9491ea4334ac0464ba89a19f",
"assets/assets/images/dummy.pdf": "2942bfabb3d05332b66eb128e0842cff",
"assets/assets/images/login_boy.png": "f16e2e2238f64aec5a4f67da481507c5",
"assets/assets/images/nointernet.png": "6db93d06a489c2457c8585b71b0e05bc",
"assets/assets/images/reading_girl.png": "8f10a2922a46c8925900a9ba1e6cd799",
"assets/assets/images/reading_girl_new.png": "8f10a2922a46c8925900a9ba1e6cd799",
"assets/assets/images/screenshot.webp": "5f6a232360bde59fb8c3c5948a645f24",
"assets/assets/images/sign_up_girl.png": "99ee7f81fa40e67870f1377247f4a861",
"assets/assets/images/splashScreen.png": "1743739460b40dfe8545280e65a24d9b",
"assets/assets/images/splashScreen_old.png": "7c1998df65ce9360ece5c7286c8c94ee",
"assets/assets/images/wave.svg": "0d3c71b903686ed41dc8e3c3626f2a44",
"assets/assets/web/loading.webp": "3c082b7223ac35d9b1e1378c91be83a4",
"assets/FontManifest.json": "6245d30daa64df7169b34bdc5e9dc48d",
"assets/fonts/MaterialIcons-Regular.otf": "1a86fd77f51632bdf26c258fc27cd895",
"assets/NOTICES": "1f41b98ba1144a5416045757eb164eec",
"assets/packages/animated_snack_bar/assets/monochrome/check-circle.svg": "f6d9dd67711da5b6d4d965f66c10cd07",
"assets/packages/animated_snack_bar/assets/monochrome/comment-dots.svg": "44311bf381ea1155bfe38c40d44c577a",
"assets/packages/animated_snack_bar/assets/monochrome/exclamation-circle.svg": "63ffc503c8e024f9752866e021afb744",
"assets/packages/animated_snack_bar/assets/monochrome/exclamation-octagon.svg": "ab5fb6de2478b95f911cebb5cf6af9c3",
"assets/packages/animated_snack_bar/assets/monochrome/exclamation-triangle.svg": "10427de487dc532646c4a11f6be3fe84",
"assets/packages/animated_snack_bar/assets/regular/check-circle.svg": "0936541fbbf9ebf325169373c2d2439a",
"assets/packages/animated_snack_bar/assets/regular/exclamation-circle.svg": "69c777fe5b9ffd2f8286ca47f98d1a31",
"assets/packages/animated_snack_bar/assets/regular/exclamation-triangle.svg": "57a895d149648e4b69c7681d4efb2052",
"assets/packages/animated_snack_bar/assets/regular/info-circle.svg": "e733e8ecda8758e6b69d20cc1ca1c6c4",
"assets/packages/csc_picker_plus/lib/assets/countries.json": "6d8c87433326342b0afebda246424e52",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "e986ebe42ef785b27164c36a9abc7818",
"assets/packages/empty_widget_fork/assets/images/emptyImage.png": "6bb2d2c61bb39c0c571b95ae009acc4b",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_1.png": "545e13e1cabb2faf7eac9801f64f7f89",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_2.png": "bcff5e23332d92e74562eaf8f47c7bd1",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_3.png": "2698f6c94cec9450ced97499b70a34d6",
"assets/packages/rflutter_alert/assets/images/2.0x/close.png": "abaa692ee4fa94f76ad099a7a437bd4f",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_error.png": "2da9704815c606109493d8af19999a65",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_info.png": "612ea65413e042e3df408a8548cefe71",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_success.png": "7d6abdd1b85e78df76b2837996749a43",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_warning.png": "e4606e6910d7c48132912eb818e3a55f",
"assets/packages/rflutter_alert/assets/images/3.0x/close.png": "98d2de9ca72dc92b1c9a2835a7464a8c",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_error.png": "15ca57e31f94cadd75d8e2b2098239bd",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_info.png": "e68e8527c1eb78949351a6582469fe55",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_success.png": "1c04416085cc343b99d1544a723c7e62",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_warning.png": "e5f369189faa13e7586459afbe4ffab9",
"assets/packages/rflutter_alert/assets/images/close.png": "13c168d8841fcaba94ee91e8adc3617f",
"assets/packages/rflutter_alert/assets/images/icon_error.png": "f2b71a724964b51ac26239413e73f787",
"assets/packages/rflutter_alert/assets/images/icon_info.png": "3f71f68cae4d420cecbf996f37b0763c",
"assets/packages/rflutter_alert/assets/images/icon_success.png": "8bb472ce3c765f567aa3f28915c1a8f4",
"assets/packages/rflutter_alert/assets/images/icon_warning.png": "ccfc1396d29de3ac730da38a8ab20098",
"assets/packages/sn_progress_dialog/images/cancel.png": "be94b63af32e39fabad56e2cab611b4b",
"assets/packages/sn_progress_dialog/images/completed.png": "4f4ec717f6bb773c80db76261bb367c3",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"canvaskit/canvaskit.js": "26eef3024dbc64886b7f48e1b6fb05cf",
"canvaskit/canvaskit.js.symbols": "efc2cd87d1ff6c586b7d4c7083063a40",
"canvaskit/canvaskit.wasm": "e7602c687313cfac5f495c5eac2fb324",
"canvaskit/chromium/canvaskit.js": "b7ba6d908089f706772b2007c37e6da4",
"canvaskit/chromium/canvaskit.js.symbols": "e115ddcfad5f5b98a90e389433606502",
"canvaskit/chromium/canvaskit.wasm": "ea5ab288728f7200f398f60089048b48",
"canvaskit/skwasm.js": "ac0f73826b925320a1e9b0d3fd7da61c",
"canvaskit/skwasm.js.symbols": "96263e00e3c9bd9cd878ead867c04f3c",
"canvaskit/skwasm.wasm": "828c26a0b1cc8eb1adacbdd0c5e8bcfa",
"canvaskit/skwasm.worker.js": "89990e8c92bcb123999aa81f7e203b1c",
"favicon.png": "7186d870932a68bb647f4fe6791d8ded",
"flutter.js": "4b2350e14c6650ba82871f60906437ea",
"flutter_bootstrap.js": "54a05fe0305cd8de7cbc40b596e95a82",
"index.html": "6e1298cef9b6d87b8b242d3d4679d660",
"/": "6e1298cef9b6d87b8b242d3d4679d660",
"main.dart.js": "d83b8c8a89e44ebf58220b009fa12ac2",
"manifest.json": "fde2b3fb6e93c44ccae7b401576bafb4",
"sitemap.xml": "c46f90d15cec400333b635cdf839ecc6",
"version.json": "5d9f103b770635cb95e954b52b430b88"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
